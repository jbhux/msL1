/*
 * HAL_MobiRob.c
 *
 * Created: 04.03.2015 17:24:39
 *  Author: Daniel
*/
 /*************************************************************************
Title:    testing output to a HD44780 based LCD display.
Author:   Peter Fleury  <pfleury@gmx.ch>  http://jump.to/fleury
File:     $Id: test_lcd.c,v 1.6 2004/12/10 13:53:59 peter Exp $
Software: AVR-GCC 3.3
Hardware: HD44780 compatible LCD text display
          ATS90S8515/ATmega if memory-mapped LCD interface is used
          any AVR with 7 free I/O pins if 4-bit IO port mode is used
**************************************************************************/
#include <stdlib.h>
#include <string.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "HAL_MobiRob.h"


/*
** constant definitions
*/
static const PROGMEM unsigned char copyRightChar[] =
{
	0x07, 0x08, 0x13, 0x14, 0x14, 0x13, 0x08, 0x07,
	0x00, 0x10, 0x08, 0x08, 0x08, 0x08, 0x10, 0x00
};


/*
** function prototypes
*/ 
void wait_until_key_pressed(void);

void wait_until_key_pressed(void)
{
	while(!key_check());
	key_get();
}

// void wait_until_key_pressed(void)
// {
// 	unsigned char temp1, temp2;
// 	unsigned int i;
// 
// 	HAL_ddr_set(L, 0);                         // PL = input
// 	HAL_port_set(L, 0xFF);                   // Pins PL0..PL5 pull-up enabled
// 	
// 	do {
// 		temp1 = PINL;                  // read input
// 		for(i=0;i<65535;i++);
// 		temp2 = PINL;                  // read input
// 		temp1 = (temp1 & temp2);       // debounce input
// 	} while ( temp1 == 0xFF);
// 
// 	do {
// 		temp1 = PINL;                  // read input
// 		for(i=0;i<65535;i++);
// 		temp2 = PINL;                  // read input
// 		temp1 = (temp1 & temp2);       // debounce input
// 	} while ( temp1 != 0xFF);
// 
// }

uint8_t is_key_pressed(void)
{
	return key_get();
}
// uint8_t is_key_pressed(void)
// {
// 	uint8_t temp1, temp2;
// 	uint16_t i;
// 
// 	HAL_ddr_set(L, 0);                         // PL = input
// 	HAL_port_set(L, 0xFF);                   // Pins PL0..PL5 pull-up enabled
// 
// 	temp1 = PINL;                  // read input
// 	for(i=0;i<65535;i++);
// 	temp2 = PINL;                  // read input
// 	temp1 = (temp1 | temp2);       // debounce input
// 	return  ~temp1;
// }

int32_t encval;

char s[20] = "";

int main(void)
{
    int  num = 4321;
    float fnum = 123.45678;
    unsigned char i;
    
	

    /* initialize display, cursor off */
    
    lcd_init(LCD_DISP_ON);
	port_init();
	system_timer_init();
	servo_init();
	motor_init();
	enc_init();
	key_init();
	adc_init(AVCC);

	
	sei();

    for (;;) {                           /* loop forever */
        /* 
         * Test 1:  write text to display
         */
        /* clear display and home cursor */
        lcd_clrscr();
        /* put string to display (line 1) with linefeed */
        lcd_puts_P("MobiRob Test Line 1\n");
        /* put string to display (line 1) with linefeed */
        lcd_puts_P("MobiRob Test Line 2\n");
        /* put string to display (line 1) with linefeed */
        lcd_puts_P("MobiRob Test Line 3\n");
        /* cursor is now on second line, write second line */
        lcd_puts_P("MobiRob Test Line 4");
        /* move cursor to position 16 on line 2 */
        lcd_gotoxy(15,1);          
        /* write single char to display */
        lcd_putc(':');
        /* wait until push button is pressed */
        wait_until_key_pressed();
         // Test 2: test servo 0
       
        lcd_gotoxy(0,0);  
        lcd_puts_P("Test 2: Servo 0 max\n");
        servo_set(0, 1000);
		servo_set(1, 1000);
		servo_set(2, 1000);
		
		motor_set(1, 1000);
		motor_set(2, 1000);
		motor_set(4, 1000);
        wait_until_key_pressed();
		
        // Test 3: test servo 0
        lcd_gotoxy(0,1);  
        lcd_puts_P("Test 3: Servo 0 500\n");
        servo_set(0, 500);
		servo_set(1, 500);
		servo_set(2, 500);
				
		motor_set(1, -500);
		motor_set(2, -500);
		motor_set(4, -500);
        wait_until_key_pressed();

		// Test 4: test servo 0
        lcd_gotoxy(0,2);  
        lcd_puts_P("Test 4: Servo0 0\n");
        
		servo_set(0, 0);
		servo_set(1, 0);
		servo_set(2, 0);
		
		motor_set(1, 0);
		motor_set(2, 0);
		motor_set(4, 0);
		wait_until_key_pressed();
     
  		// Test 5: Encoder einlesen
  		
  		lcd_clrscr();   /* clear display home cursor */
  		lcd_puts_P("Test 5, Encoder:");
  		
  		i = 1;
  		direction_set(2, +1);
  		while(!is_key_pressed())
  		{
	  		volatile static uint32_t t;
	  		encval=enc_get(i);
	  		{
		  		lcd_gotoxy(0,i);
		  		lcd_puts_P("...........");
		  		ltoa(encval,s,10);
		  		lcd_gotoxy(0,i);
		  		lcd_puts(s);
	  		}
	  		(i>=2)?(i=1):(i=2);
	  		t = time_get()+20;
	  		while (t>time_get());
	  		//_delay_ms(20);
  	}
	  
	// Test 6: ADC einlesen
  	
  	lcd_clrscr();   /* clear display home cursor */
  	lcd_puts_P("Test 6, ADC");
  	
  	i = 1;
  	direction_set(2, +1);
  	while(!is_key_pressed())
  	{
	  	volatile static uint32_t t;
	  	num=adc_read(9); // MAGNET
	  	{
		  	lcd_gotoxy(0,1);
		  	lcd_puts_P("          ");
		  	itoa(num,s,10);
		  	lcd_gotoxy(0,1);
		  	lcd_puts(s);
	  	}
	  	t = time_get()+20;
	  	while (t>time_get());
	  	//_delay_ms(20);
  	}
		   
       
      
        /*
         *  Test 5: Display userdefined characters
         */

       lcd_clrscr();   /* clear display home cursor */
       
       lcd_puts_P("Test 7, Copyright:");
       
       /*
        * load two userdefined characters from program memory
        * into LCD controller CG RAM location 0 and 1
        */
       lcd_command(_BV(LCD_CGRAM));  /* set CG RAM start address 0 */
       for(i=0; i<16; i++)
       {
           lcd_data(pgm_read_byte_near(&copyRightChar[i]));
       }
       
       /* move cursor to position 0 on line 2 */
       /* Note: this switched back to DD RAM adresses */
       lcd_gotoxy(0,1);
       
       /* display user defined (c), built using two user defined chars */
       lcd_putc(0);
       lcd_putc(1);
       
       wait_until_key_pressed();
              
        lcd_clrscr();     /* clear display home cursor */
        lcd_puts_P("Test 8: Float\n");
        lcd_putf(fnum, 8, 3);
        //Ausgabe einer Flie�kommazahl mit sges Gesamtstellen. 
        //Hiervon sind snach Nachkommastellen.
        //Die Nachkollastellen werden gerundet. (TSC)
        wait_until_key_pressed();

        lcd_clrscr();     /* clear display home cursor */
        lcd_puts_P("Test 9: bin\n");
        lcd_putui_bin(num, 20);
        //Ausgabe der Integerzahl zahl formatiert  mit sges Stellen(TSC)
        // Das Ausgabeformat ist bin�r. Leerstellen werden mit 0 aufgef�llt.
        wait_until_key_pressed();
    }
}
/////////////////////////////////
/*
void pinchange_PJ6(uint8_t edge)
{
	ddr_set(G, 0x03);
	port_set(G, port_get(G)|0x01);
	if(edge > 0) // steigende Flanke
	{
		port_set(G, port_get(G)|0x02);
	}
	else
	{
		port_set(G, port_get(G)&~0x02);
	}
	port_set(G, port_get(G)&~0x01);
}
*/