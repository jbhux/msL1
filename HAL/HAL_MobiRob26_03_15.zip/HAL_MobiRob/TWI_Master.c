/** ***************************************************************************
* Atmel Corporation
*
* \file              : TWI_Master.c
* Compiler          : GNU Toolchain - 3.4.2.1002 GCC_VERSION:4.7.2
* Revision          : $Revision: 1.13 $
* Date              : \Date: 20.11.2013 11:31:20 $
* Updated by        : \Author: D.M.Binggeli $
*
* 
* Supported devices : All devices with a TWI module can be used.
*                     The example is written for the ATmega168
*
* AppNote           : AVR315 - TWI Master Implementation
*
* \brief       : This is a sample driver for the TWI hardware modules.
* It is interrupt driven. All functionality is controlled through 
* passing information to and from functions. 
*
***************************************************************************/


#include <avr/io.h>              
#include <avr/interrupt.h>
#include <stdbool.h>

#include "TWI_Master.h"

static unsigned char TWI_buf[ TWI_BUFFER_SIZE ];    // Transceiver buffer
static unsigned char TWI_msgSize;                   // Number of bytes to be transmitted.
static unsigned char TWI_state = TWI_NO_STATE;      // State byte. Default set to TWI_NO_STATE.

union TWI_statusReg TWI_statusReg = {0};            // TWI_statusReg is defined in TWI_Master.h

/** **************************************************************************
\brief Call this function to set up the TWI master to its initial standby state.
Remember to enable interrupts from the main application after initializing the TWI.
****************************************************************************/
void TWI_Master_Initialise(void)
{
  TWBR = TWI_TWBR;                                  //! Set bit rate register (Baud rate). Defined in header file.
// TWSR = TWI_TWPS;                                  //! Not used. Driver presumes prescaler to be 00.
  TWDR = 0xFF;                                      //! Default content = SDA released.
  TWCR = (1<<TWEN)|                                 //! Enable TWI-interface and release TWI pins.
         (0<<TWIE)|(0<<TWINT)|                      //! Disable interrupt.
         (0<<TWEA)|(0<<TWSTA)|(0<<TWSTO)|           //! No Signal requests.
         (0<<TWWC);                                 //
}    
    
/** **************************************************************************
\brief Call this function to fetch the state information of the previous operation. 
\attention The function will hold execution (loop) until the TWI_ISR has completed with the previous operation. 
If there was an error, then the function will return the TWI State code. 
****************************************************************************/
unsigned char TWI_Get_State_Info( void )
{
  while ( TWI_Transceiver_Busy() );             // Wait until TWI has completed the transmission.
  return ( TWI_state );                         // Return error state.
}

/** **************************************************************************
\brief Call this function to send a prepared message. 
The first byte must contain the slave address and the read/write bit. 
Consecutive bytes contain the data to be sent, or empty locations for data to be read
from the slave. Also include how many bytes that should be sent/read including the address byte.
\attention The function will hold execution (loop) until the TWI_ISR has completed with 
the previous operation, then initialize the next operation and return.
****************************************************************************/
void TWI_Start_Transceiver_With_Data( unsigned char *msg, unsigned char msgSize )
{
  unsigned char temp;

  while ( TWI_Transceiver_Busy() );             /// Wait until TWI is ready for next transmission.

  TWI_msgSize = msgSize;                        /// Number of data to transmit.
  TWI_buf[0]  = msg[0];                         /// Store slave address with R/W setting.
  if (!( msg[0] & (1<<TWI_READ_BIT) ))         /// If it is a write operation, then also copy data.
  {
    for ( temp = 1; temp < msgSize; temp++ )
      TWI_buf[ temp ] = msg[ temp ];
  }
  TWI_statusReg.all = 0;      
  TWI_state         = TWI_NO_STATE ;
  TWCR = (1<<TWEN)|                             /// TWI interface enabled.
         (1<<TWIE)|(1<<TWINT)|                  /// Enable TWI interrupt and clear the flag.
         (0<<TWEA)|(1<<TWSTA)|(0<<TWSTO)|       /// Initiate a START condition.
         (0<<TWWC);                             //
}

/** **************************************************************************
\brief Call this function to resend the last message. The driver will reuse the data previously put in the transceiver buffers.
\attention The function will hold execution (loop) until the TWI_ISR has completed with the previous operation,
then initialize the next operation and return.
****************************************************************************/
void TWI_Start_Transceiver( void )
{
  while ( TWI_Transceiver_Busy() );             /// Wait until TWI is ready for next transmission.
  TWI_statusReg.all = 0;      
  TWI_state         = TWI_NO_STATE ;
  TWCR = (1<<TWEN)|                             /// TWI interface enabled.
         (1<<TWIE)|(1<<TWINT)|                  /// Enable TWI interrupt and clear the flag.
         (0<<TWEA)|(1<<TWSTA)|(0<<TWSTO)|       /// Initiate a START condition.
         (0<<TWWC);                             //
}

/** **************************************************************************
\brief Call this function to read out the requested data from the TWI transceiver buffer. I.e. first call
TWI_Start_Transceiver to send a request for data to the slave. Then Run this function to collect the
data when they have arrived. Include a pointer to where to place the data and the number of bytes
requested (including the address field) in the function call.
\attention The function will hold execution (loop) until the TWI_ISR has completed with the previous operation, 
before reading out the data and returning.
If there was an error in the previous transmission the function will return the TWI error code.
****************************************************************************/
unsigned char TWI_Get_Data_From_Transceiver( unsigned char *msg, unsigned char msgSize )
{
  unsigned char i;

  while ( TWI_Transceiver_Busy() );             // Wait until TWI is ready.

  if( TWI_statusReg.lastTransOK )               // Last transmission completed successfully.              
  {                                             
    for ( i=0; i<msgSize; i++ )                 // Copy data from transceiver buffer.
    {
      msg[ i ] = TWI_buf[ i ];
    }
  }
  return( TWI_statusReg.lastTransOK );                                   
}

// ********** Interrupt Handler ********** //
/****************************************************************************
\brief This function is the Interrupt Service Routine (ISR), and called when the TWI interrupt is triggered;
that is whenever a TWI event has occurred. 
\attention This function should not be called directly from the main application.
****************************************************************************/

ISR (TWI_vect)
{
	static unsigned char TWI_bufPtr;
#ifdef TWI_DEBUG
	PORTB |= _BV(PB0);  // Gr�ne LED zum Test
#endif
	switch (TWSR)
	{
	case TWI_START:             /// START has been transmitted  
	case TWI_REP_START:         /// Repeated START has been transmitted
		TWI_bufPtr = 0;										// Set buffer pointer to the TWI Address location
	case TWI_MTX_ADR_ACK:       /// SLA+W has been transmitted and ACK received
	case TWI_MTX_DATA_ACK:      /// Data byte has been transmitted and ACK received
		if (TWI_bufPtr < TWI_msgSize)
		{
			TWDR = TWI_buf[TWI_bufPtr++];
			TWCR = (1<<TWEN)|(1<<TWIE)|(1<<TWINT);			/// TWI Interface enabled
			// Enable TWI interrupt and clear the flag to send byte
		}
		else						/// Send STOP after last byte
		{
			TWI_statusReg.lastTransOK = true;				/// Set status bits to completed successfully. 
			if (TWI_msgSize>2)		/// it was a register write-command
			{
				TWCR = (1<<TWEN)|(1<<TWINT)|(1<<TWSTO);		/// TWI Interface enabled
				/// clear the interrupt flag, initiate a STOP condition.
						           
			}
			else					// it was a register read-command
			{
				TWI_buf[0] |= (1<<TWI_READ_BIT);			// restart wit read bit set
				TWCR = (1<<TWEN)|(1<<TWIE)|(1<<TWINT)|(1<<TWSTA);// TWI interface enabled.
				// Enable TWI interrupt and clear the flag, initiate a START condition.
			}
		}
		break;
	case TWI_MRX_DATA_ACK:      /// Data byte has been received and ACK transmitted
		TWI_buf[TWI_bufPtr++] = TWDR;
	case TWI_MRX_ADR_ACK:       /// SLA+R has been transmitted and ACK received
		if (TWI_bufPtr < (TWI_msgSize-1) )       // Detect the last byte to NACK it.
		{
			TWCR = (1<<TWEN)|(1<<TWIE)|(1<<TWINT)|(1<<TWEA);// TWI interface enabled
			// Enable TWI interrupt, clear the flag, send ACK after reception
		}
		else						// Send NAK after next reception
		{
		TWCR = (1<<TWEN)|(1<<TWIE)|(1<<TWINT);				// TWI interface enabled
		// Enable TWI interrupt, clear the flag, send NAK after reception
		}    
		break; 
	case TWI_MRX_DATA_NACK:		/// Data byte has been received and NACK transmitted
		TWI_buf[TWI_bufPtr] = TWDR;							// save data byte to buffer
		TWI_statusReg.lastTransOK = true;					// Set status bits to completed successfully. 
		TWCR = (1<<TWEN)|(1<<TWINT)|(1<<TWSTO);				// TWI interface enabled
		// Disable TWI interrupt, clear the flag, initiate a STOP condition.
		break;      
	case TWI_ARB_LOST:          /// Arbitration lost
		TWCR = (1<<TWEN)|(1<<TWIE)|(1<<TWINT)|(1<<TWSTA);	// TWI interface enabled
		// Enable TWI interrupt, clear the flag, initiate a (RE)START condition.
		break;
	case TWI_MTX_ADR_NACK:      /// SLA+W has been transmitted and NACK received
	case TWI_MRX_ADR_NACK:      /// SLA+R has been transmitted and NACK received    
	case TWI_MTX_DATA_NACK:     /// Data byte has been transmitted and NACK received
	case TWI_NO_STATE:          /// No relevant state information available; TWINT = �0�
	case TWI_BUS_ERROR:         /// Bus error due to an illegal START or STOP condition
	default:     
		TWI_state = TWSR;									// Store TWSR and automatically sets noErrors bit.
															// Reset TWI interface
		TWCR = (1<<TWEN);									// Enable TWI-interface, No signal requests
	}
#ifdef TWI_DEBUG
	PORTB &= ~_BV(PB0);  // Gr�ne LED zum Test
#endif
}
